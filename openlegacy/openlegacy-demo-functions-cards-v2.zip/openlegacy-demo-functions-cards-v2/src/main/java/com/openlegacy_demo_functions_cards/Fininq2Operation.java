package com.openlegacy_demo_functions_cards;

import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.openlegacy.core.rpc.RpcEntity;

import io.ol.core.annotation.RpcOperation;
import io.ol.core.annotation.RpcOperationOutput;
import io.ol.core.rpc.operation.Operation;
import io.ol.core.rpc.operation.OperationDefinition;
import lombok.Getter;

/**
 * @author Tom Fingerman 22/01/2020.
 */
@RpcOperation
@Getter(onMethod_ = {@NotNull})
public class Fininq2Operation implements Operation<Fininq2> {
    private final Fininq2 input;
    private final String path = "FININQ2";
    @RpcOperationOutput(statusCode = 200, entityType = Fininq2.class)
    private final Map<Integer, RpcEntity> outputMap;

    public Fininq2Operation(Fininq2 input) {
        this.input = input;
        this.outputMap = Fininq2OperationHelper.initOutputMap();
    }

    @NotNull
    @Override
    public OperationDefinition operationDefinition() {
        return Fininq2OperationHelper.operationDefinition;
    }
}