package com.openlegacy_demo_functions_cards;

import java.io.BufferedWriter;
import java.io.IOException;

import com.google.cloud.functions.HttpFunction;
import com.google.cloud.functions.HttpRequest;
import com.google.cloud.functions.HttpResponse;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import io.vertx.core.json.Json;

public class EntryClass implements HttpFunction {
  
  private static final Gson gson = new Gson();
  
  @Override
  public void service(HttpRequest request, HttpResponse response)
      throws IOException {
    BufferedWriter writer = response.getWriter();
	OpenLegacyWrapper openLegacyWrapper = new OpenLegacyWrapper(); 
    
	String customerId = request.getFirstQueryParameter("customerId").orElse("no");
    // Parse JSON request and check for "customerId" field
    try {
      JsonElement requestParsed = gson.fromJson(request.getReader(), JsonElement.class);
      JsonObject requestJson = null;

      if (requestParsed != null && requestParsed.isJsonObject()) {
        requestJson = requestParsed.getAsJsonObject();
      }

      if (requestJson != null && requestJson.has("customerId")) {
    	  customerId = requestJson.get("customerId").getAsString();
      } else {
    	  writer.write("customerId not sent");
    	  return;
      }
    } catch (JsonParseException e) {
    	writer.write("Error parsing JSON: " + e.getMessage());
    	return;
    }
	writer.write(Json.encodePrettily(openLegacyWrapper.obtainCreditCardInfo(customerId)));
  response.appendHeader("Content-Type","application/json");
	
  }
}