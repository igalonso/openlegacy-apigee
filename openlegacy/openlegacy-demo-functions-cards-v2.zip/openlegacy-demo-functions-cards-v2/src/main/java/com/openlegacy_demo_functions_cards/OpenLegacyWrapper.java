package com.openlegacy_demo_functions_cards;

import java.io.BufferedWriter;
import java.util.List;

import io.ol.core.rpc.RpcRequest;
import io.ol.core.rpc.RpcResponse;
import io.ol.provider.mfcicsts.MfCicsRpcConnection;
import io.ol.provider.mfcicsts.MfCicsRpcConnectionFactory;
import io.vertx.core.json.Json;

public class OpenLegacyWrapper {
	  
	
	public OpenLegacyWrapper() {
		super();
	}
	
	public List<Fininq2CreditCards> obtainCreditCardInfo(String customerId) {
		
		MfCicsRpcConnectionFactory factory = MfCicsRpcConnectionFactorySingleton.INSTANCE.getFactory();
		try (MfCicsRpcConnection connection = factory.getConnection()) {
		      
			Fininq2 fininq2 = new Fininq2();
			fininq2.setDfhcommarea(new Fininq2Dfhcommarea());
			fininq2.getDfhcommarea().setCustId(customerId);
			Fininq2Operation operation = new Fininq2Operation(fininq2);
		    RpcRequest<Fininq2> request = new RpcRequest(operation);
		      
		    RpcResponse response = connection.invokeSync(request);
		      		      
		    if (response.getStatusCode() == 200) {
		    	Fininq2 fininq2Response = response.body(Fininq2.class);
			    List<Fininq2CreditCards> innerRecords = fininq2Response.getDfhcommarea().getCreditCards();
			    return innerRecords;
		     } else {
		    	 return null;
		     }
		   
		  }
			
	  }

}
