package com.openlegacy_demo_functions_cards;

import io.ol.provider.mfcicsts.MfCicsRpcConnectionFactory;
import io.ol.provider.mfcicsts.dsl.MfCicsProviderDslKt;
import io.ol.provider.mfcicsts.dsl.MfCicsProviderOptions;
import io.ol.provider.mfcicsts.properties.OLCicsProperties;

public enum MfCicsRpcConnectionFactorySingleton {
	
    INSTANCE;
    
	private final MfCicsRpcConnectionFactory mfCicsRpcConnectionFactory;
    
	MfCicsRpcConnectionFactorySingleton() {
        OLCicsProperties.ProjectCicsProperties projectCicsProperties = new OLCicsProperties.ProjectCicsProperties();
        projectCicsProperties.setCodePage("cp037");
        projectCicsProperties.setBaseUrl("http://192.86.32.238");
        projectCicsProperties.setPort(12345);
        projectCicsProperties.setUriMap("dev/latest");
        this.mfCicsRpcConnectionFactory = MfCicsProviderDslKt.mfCicsRpcConnectionFactory(projectCicsProperties, new MfCicsProviderOptions());
    }
    
	public MfCicsRpcConnectionFactory getFactory() {
        return mfCicsRpcConnectionFactory;
    }
}
