//var sfdcUserId = '0035J000002ELHsQAO';
var sfdcUserId = context.getVariable('proxy.pathsuffix').split('/')[1];
//var path = 'v1/loyalty/123124/recommendation';
var userId = 0;
var index = 0;
for (;index < sfdcUserId.length; index++) {
    var ch = sfdcUserId.charAt(index);
    var sum = ch.charCodeAt(0);
    userId = userId + sum;
}
context.setVariable('user.id',userId.toString());
