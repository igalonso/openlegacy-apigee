var response = properties.response; 
var cards = JSON.parse(context.getVariable(response)); 
var total = 0;
var index = 0;
for (;index < cards.creditCards.length; index++) {
    total = total + cards.creditCards[index]['cardUsage'];
}

context.setVariable('user.totalpoints',Math.trunc(total).toString());