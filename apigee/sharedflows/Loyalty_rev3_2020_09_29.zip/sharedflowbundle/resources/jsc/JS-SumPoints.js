//var response = properties.response[0];
var cards = context.getVariable("cards").toString();
cards =JSON.parse(cards);
print(cards);
cards

var total = 0;
cards.forEach(function (item){
    total = total + item['cardUsage'];
});

context.setVariable('user.totalpoints',Math.trunc(total).toString());